﻿using System;
using System.Data.SqlClient;

namespace CapaDatos
{
    public class Conexion
    {
        // Patron de diseño Singleton
        private static readonly Conexion _instancia = new Conexion();

        public static Conexion Instancia
        {
            get { return Conexion._instancia; }
        }

        public SqlConnection Conectar()
        {
            SqlConnection cn = new SqlConnection();
            cn.ConnectionString = @"Data Source=localhost; Initial Catalog=DBIncidencias; Integrated Security=true";
            return cn;
        }
    }
}
